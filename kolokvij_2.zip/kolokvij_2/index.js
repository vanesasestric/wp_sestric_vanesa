
let broj = prompt("Unesite jedan broj:");

broj = Number(broj);

let rezultat = broj * 2;

alert("Unio si broj " + broj + ", a dva puta veći broj je " + rezultat);